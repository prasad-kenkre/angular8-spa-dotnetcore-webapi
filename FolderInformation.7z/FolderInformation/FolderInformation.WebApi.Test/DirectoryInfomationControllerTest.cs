﻿#region "Copyright Notice <Company_Name>"
//
// All rights are reserved. Reproduction or transmission in whole or 
// in part, in any form or by any means, electronic, mechanical or 
// otherwise, is prohibited without the prior written consent of the 
// copyright owner.
//
// Filename: DirectoryInformationControllerTest.cs
#endregion

using FolderInformation.BusinessComponents;
using FolderInformation.DataContracts;
using FolderInformation.WebApi.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FolderInformation.WebApi.Test.Controllers
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable", Justification = "Dispose in TestCleanup")]
    [TestClass]
    /// <summary>
    /// Test class for DirectoryInformationController
    /// </summary>
    public class DirectoryInformationControllerTest
    {
        #region "Setup"

        #region "Private Variables"
        /// <summary>
        /// mocked DirectoryInformation Component
        /// </summary>
        private Mock<IDirectoryInformationComponent> mockedDirectoryInformationComponent;

        private DirectoryInfomationController controller;
        private List<DirectoryInformation> folderList;
        private DirectoryInformationInputFilter filter;
        #endregion

        #region "Constants"
        private const string VALID_FOLDER_PATH = "C:\\";
        private const string INVALID_FOLDER_PATH = "";
        private const string FOLDER_NAME = "ABC";
        private const long FOLDER_SIZE = 10;
        #endregion

        /// <summary>
        /// Initialize for testing
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            mockedDirectoryInformationComponent = new Mock<IDirectoryInformationComponent>();
            controller = new DirectoryInfomationController(mockedDirectoryInformationComponent.Object);
            filter = new DirectoryInformationInputFilter();

            folderList = new List<DirectoryInformation>()
            {
               new DirectoryInformation { FolderName = FOLDER_NAME, FolderSize = FOLDER_SIZE}
            };

            folderList = new List<DirectoryInformation>();
        }

        /// <summary>
        /// Tests the cleanup.
        /// </summary>
        [TestCleanup]
        public void TestCleanup()
        {
            controller.Dispose();
            controller = null;
        }
        #endregion

        #region "Test Cases"
        /// <summary>
        /// DirectoryInformation contoller constuctor is invoked with null component, and throws ArgumentNullException
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CheckDirectoryInformationControllerArgumentNullException()
        {
            new DirectoryInfomationController(null);
        }

        /// <summary>
        /// <summary>
        /// DirectoryInformationController Get is called and all business components are called only once
        /// </summary>
        [TestMethod]
        public void CheckAllDirectoryInformationsOnce()
        {
            filter.FolderPath = VALID_FOLDER_PATH;
            var result = controller.Get(filter);
            mockedDirectoryInformationComponent.Verify(m => m.GetFolderListAsync(filter), Times.Once);
        }

        /// <summary>
        /// Check Directory Information For Valid Folder Path
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        public void CheckDirectoryInformationForValidFolderPath()
        {
            filter.FolderPath = VALID_FOLDER_PATH;
            mockedDirectoryInformationComponent.Setup(arg => arg.GetFolderListAsync(filter)).ReturnsAsync(folderList);

            var result = controller.Get(filter);
            Assert.IsNotNull(result.Result);
        }

        /// <summary>
        /// Check Directory Information For Invalid Folder Path
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        //[ExpectedException(typeof(InvalidDataException))]
        public void CheckDirectoryInformationForInvalidFolderPath()
        {
            filter.FolderPath = INVALID_FOLDER_PATH;
            mockedDirectoryInformationComponent.Setup(arg => arg.GetFolderListAsync(filter)).Throws<InvalidDataException>();
            var result = controller.Get(filter);
            Assert.AreEqual(result.Exception.InnerException.Message, "Found invalid data while decoding.");
        }
        #endregion
    }
}
