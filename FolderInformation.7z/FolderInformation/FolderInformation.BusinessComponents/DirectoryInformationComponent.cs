﻿#region "Copyright Notice <Company_Name>"
//
// All rights are reserved. Reproduction or transmission in whole or 
// in part, in any form or by any means, electronic, mechanical or 
// otherwise, is prohibited without the prior written consent of the 
// copyright owner.
//
// Filename: DirectoryInformationComponent.cs
#endregion

using FolderInformation.DataContracts;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FolderInformation.BusinessComponents
{
    public class DirectoryInformationComponent : IDirectoryInformationComponent
    {
        #region "EndPoints"
        /// <summary>
        /// Directory Information Input Filter.
        /// </summary>
        /// <param name="filter">Directory Information Input Filter</param>  
        public Task<List<DirectoryInformation>> GetFolderListAsync(DirectoryInformationInputFilter filter)
        {
            if (string.IsNullOrEmpty(filter.FolderPath) || string.IsNullOrWhiteSpace(filter.FolderPath))
            {
                throw new InvalidDataException();
            }
            else
            {
                if (Directory.Exists(filter.FolderPath))
                {
                    return Task.FromResult(MapDirs(filter.FolderPath));
                }
                else
                {
                    throw new DirectoryNotFoundException();
                }
            }
        }
        #endregion

        #region "Private Methods"
        /// <summary>
        /// Gets top 5 folders with their folder size in descending order.
        /// </summary>
        /// <param name="realPath">Directory Path</param>  
        private List<DirectoryInformation> MapDirs(String realPath)
        {
            if (string.IsNullOrEmpty(realPath) || string.IsNullOrWhiteSpace(realPath)) return null;

            List<DirectoryInformation> dirListModel = new List<DirectoryInformation>();

            IEnumerable<string> dirList = Directory.EnumerateDirectories(realPath);
            foreach (string dir in dirList)
            {
                long directorySize = GetDirectorySize(dir);

                DirectoryInformation folderInfo = new DirectoryInformation
                {
                    FolderName = Path.GetFileName(dir),
                    FolderSize = directorySize,
                    FolderSizeString = GetDirectorySizeString(directorySize)
                };

                dirListModel.Add(folderInfo);
            }

            if(dirListModel.Count() > 0)
            {
                dirListModel = dirListModel
                .OrderByDescending(s => s.FolderSize)
                .Take(5)
                .ToList();
            }

            return dirListModel;
        }
        
        /// <summary>
        /// Gets folder size for a given path.
        /// </summary>
        /// <param name="fullDirectoryPath">Directory Path</param>  
        private static long GetDirectorySize(string fullDirectoryPath)
        {
            long directorySize = 0;
            if (!Directory.Exists(fullDirectoryPath))
                return directorySize; //Return 0 while Directory does not exist.

            var currentDirectory = new DirectoryInfo(fullDirectoryPath);

            //Add size of files in the Current Directory to main size.
            currentDirectory.GetFiles().ToList().ForEach(f => directorySize += f.Length);

            //Loop on Sub Direcotries in the Current Directory and Calculate it's files size.
            currentDirectory.GetDirectories().ToList()
                .ForEach(d => directorySize += GetDirectorySize(d.FullName));

            return directorySize;  //Return full Size of this Directory.
        }
        
        /// <summary>
        /// Gets folder size for a given path along with human readable format like KB, MB or GB etc.
        /// </summary>
        /// <param name="bytes">Directory Path</param>  
        private static string GetDirectorySizeString(Int64 bytes)
        {
            // Load all suffixes in an array  
            string[] suffixes = { "Bytes", "KB", "MB", "GB", "TB", "PB" };
            int counter = 0;
            decimal number = (decimal)bytes;
            while (number >= 1024 && Math.Round(number / 1024) >= 1)
            {
                number = number / 1024;
                counter++;
            }
            return string.Format("{0:n2} {1}", number, suffixes[counter]);
        }
        #endregion
    }
}
