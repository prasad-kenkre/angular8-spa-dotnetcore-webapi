﻿#region "Copyright Notice <Company_Name>"
//
// All rights are reserved. Reproduction or transmission in whole or 
// in part, in any form or by any means, electronic, mechanical or 
// otherwise, is prohibited without the prior written consent of the 
// copyright owner.
//
// Filename: DirectoryInformationController.cs
#endregion

using FolderInformation.BusinessComponents;
using FolderInformation.DataContracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FolderInformation.WebApi.Controllers
{
    /// <summary>
    /// Directory Infomation Controller Class.
    /// </summary>
    [ApiController]
    public class DirectoryInfomationController : Controller
    {
        #region "Setup"
        private readonly IDirectoryInformationComponent _folderComponent;

        /// <summary>
        /// Directory Infomation Controller Constructor.
        /// </summary>
        /// <param name="folderComponent">IDirectoryInformationComponent</param>  
        public DirectoryInfomationController(IDirectoryInformationComponent folderComponent)
        {
            _folderComponent = folderComponent ?? throw new ArgumentNullException(nameof(folderComponent));
        }
        #endregion

        #region "EndPoints"
        /// <summary>
        /// Get top 5 folder names along with their sizes for a given specified path.
        /// </summary>
        /// <param name="filter">Directory Information Input Filter</param>  
        [HttpGet]
        [Route("api/directoryinfomation", Name = "GetDirectoryInfomation")]
        public async Task<List<DirectoryInformation>> Get([FromQuery] DirectoryInformationInputFilter filter)
        {
            try
            {
                var result = await _folderComponent.GetFolderListAsync(filter);
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}