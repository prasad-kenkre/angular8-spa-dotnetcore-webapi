﻿#region "Copyright Notice <Company_Name>"
//
// All rights are reserved. Reproduction or transmission in whole or 
// in part, in any form or by any means, electronic, mechanical or 
// otherwise, is prohibited without the prior written consent of the 
// copyright owner.
//
// Filename: Startup.cs
#endregion

using FolderInformation.BusinessComponents;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.IO;

namespace FolderInformation.WebApi
{
    /// <summary>
    /// Startup Class.
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        /// </summary>
        /// <param name="services">ConfigureServices</param>  

        public void ConfigureServices(IServiceCollection services)
        {
            // Configire CORS Policy. Must be configured before AddMVc().
            services.AddCors(options => options.AddPolicy("ApiCorsPolicy", builder =>
            {
                builder.AllowAnyOrigin()
                       .AllowAnyMethod()
                       .AllowAnyHeader()
                       .AllowCredentials();
            }));
            
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // DI
            ConfigureDependencyInjection(services);

            // Swagger
            ConfigureSwagger(services);
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">app</param>  
        /// <param name="env">env</param>  

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
                app.UseExceptionHandler("/error");
            }

            app.UseStatusCodePages();
            app.UseHttpsRedirection();

            // Use CORS Policy
            app.UseCors("ApiCorsPolicy");

            app.UseMvc();

            app.UseSwagger();

            app.UseSwaggerUI(c =>
                                {
                                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Directory Information");
                                    c.RoutePrefix = string.Empty; // To serve the Swagger UI at the app's root (http://localhost:<port>/)
                                }
                            );
        }
        
        /// <summary>
        /// Configure Dependency Injection.
        /// </summary>
        /// <param name="services">ConfigureDependencyInjection</param>  
        public void ConfigureDependencyInjection(IServiceCollection services)
        {
            services.AddScoped<IActionContextAccessor, ActionContextAccessor>();
            services.AddScoped<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<IDirectoryInformationComponent, DirectoryInformationComponent>();
        }
        
        /// <summary>
        /// Configure Swagger.
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        public void ConfigureSwagger(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "Directory Information",
                    Description = "Directory Information using ASP.NET Core Web API",
                });

                // Set the comments path for the Swagger JSON and UI.
                var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                var commentsFileName = "SwaggerComments.xml";
                var commentsFile = Path.Combine(baseDirectory, commentsFileName);
                c.IncludeXmlComments(commentsFile);
            });
        }
    }
}
