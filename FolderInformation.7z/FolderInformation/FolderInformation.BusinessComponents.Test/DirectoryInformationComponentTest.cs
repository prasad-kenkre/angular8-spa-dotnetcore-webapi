﻿#region "Copyright Notice <Company_Name>"
//
// All rights are reserved. Reproduction or transmission in whole or 
// in part, in any form or by any means, electronic, mechanical or 
// otherwise, is prohibited without the prior written consent of the 
// copyright owner.
//
// Filename: DirectoryInformationComponentTest.cs
#endregion

using FolderInformation.DataContracts;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.IO;

namespace FolderInformation.BusinessComponents.Test
{
    [TestClass]
    public class DirectoryInformationComponentTest
    {
        #region "Setup"

        #region "Private Variables"
        /// <summary>
        /// Directory Information Component.
        /// </summary>
        private Mock<IDirectoryInformationComponent> mockedDirectoryInformationComponent;

        /// <summary>
        /// Directory Information Input Filter.
        /// </summary>
        private DirectoryInformationInputFilter filter;
        private List<DirectoryInformation> folderList;
        #endregion

        #region "Constants"
        private const string VALID_FOLDER_PATH = "C:\\";
        private const string INVALID_FOLDER_PATH = "";
        private const string FOLDER_NAME = "ABC";
        private const long FOLDER_SIZE = 10;
        #endregion

        /// <summary>
        /// Tests the initialize.
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            mockedDirectoryInformationComponent = new Mock<IDirectoryInformationComponent>();
            filter = new DirectoryInformationInputFilter();

            folderList = new List<DirectoryInformation>()
            {
               new DirectoryInformation { FolderName = FOLDER_NAME, FolderSize = FOLDER_SIZE}
            };            
        }
        #endregion

        #region "Test Cases"
        /// <summary>
        /// Check Directory Information For Valid FolderPath.
        /// </summary>
        [TestMethod]
        public void CheckDirectoryInformationForValidFolderPath()
        {
            filter.FolderPath = VALID_FOLDER_PATH;
            var result = mockedDirectoryInformationComponent.Setup(arg => arg.GetFolderListAsync(filter)).ReturnsAsync(folderList);
            Assert.IsNotNull(result);
        }

        /// <summary>
        /// Check Directory Information For Invalid FolderPath.
        /// </summary>
        [TestMethod]
        public void CheckDirectoryInformationForInvalidFolderPath()
        {
            filter.FolderPath = INVALID_FOLDER_PATH;
            var result = mockedDirectoryInformationComponent.Setup(arg => arg.GetFolderListAsync(filter)).Throws<InvalidDataException>();
        }
        #endregion
    }
}

